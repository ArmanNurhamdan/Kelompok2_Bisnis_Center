<section class="py-5">
    <div class="container">
        <div class="card rounded-0">
            <div class="card-body">
            SEJARAH BERDIRINYA BISNIS CENTER 
            SMKN 1 BOGOR


            Pada 4 Mei 2015, SMK Negeri 1 Kota Bogor meresmikan program "Alfamart Class" bekerja sama dengan PT Sumber Alfaria Trijaya Tbk, pengelola jaringan ritel Alfamart. Program ini bertujuan untuk meningkatkan kualitas pendidikan dan kompetensi siswa, khususnya dalam bidang pemasaran ritel. 
            Sebagai bagian dari kerja sama ini, Alfamart merenovasi laboratorium bisnis di SMKN 1 Bogor menjadi toko Alfamart yang berfungsi sebagai media praktik bagi siswa. Dengan adanya laboratorium ini, siswa dapat memperoleh pengalaman langsung dalam mengelola operasional toko ritel, mulai dari manajemen stok hingga pelayanan pelanggan. 
            Wali Kota Bogor saat itu, Bima Arya, mengapresiasi inisiatif ini dan berharap business center tersebut dapat dikelola secara profesional oleh siswa, serta mampu menampung produk-produk lokal untuk memberdayakan warga Kota Bogor. 
            Program "Alfamart Class" di SMKN 1 Bogor merupakan bagian dari inisiatif Alfamart untuk menjalin kerja sama dengan berbagai SMK di Indonesia. Hingga saat itu, program serupa telah diimplementasikan di sekitar 60 sekolah di 14 kota di seluruh Indonesia. 
            Selain memberikan fasilitas laboratorium, Alfamart juga melakukan sinkronisasi kurikulum pendidikan ritel dan memberikan pelatihan kepada tenaga pengajar dan siswa. Hal ini diharapkan dapat meningkatkan kompetensi lulusan SMK, sehingga siap bersaing di dunia kerja, khususnya di industri ritel. 
            Dengan adanya program ini, SMKN 1 Bogor berupaya mencetak lulusan yang tidak hanya memiliki pengetahuan teoretis, tetapi juga keterampilan praktis yang sesuai dengan kebutuhan industri, khususnya dalam bidang bisnis daring dan pemasaran.
            </div>
        </div>
    </div>
</section>